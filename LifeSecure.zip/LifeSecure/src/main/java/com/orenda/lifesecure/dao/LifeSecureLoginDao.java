package com.orenda.lifesecure.dao;

public interface LifeSecureLoginDao {

	void getUserInDb(String emailId);

}
