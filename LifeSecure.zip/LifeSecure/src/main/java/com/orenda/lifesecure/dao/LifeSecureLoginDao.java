package com.orenda.lifesecure.dao;

import com.orenda.lifesecure.model.User;

public interface LifeSecureLoginDao {

	void getUserInDb(String emailId);

	User verifyUser(String useremail);

}
