package com.orenda.lifesecure.controller;

import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.orenda.lifesecure.model.User;
import com.orenda.lifesecure.service.LifeSecureLoginService;

@Controller
@RequestMapping("/login")
@SessionAttributes
public class LifeSecureLoginController {
	
	@Autowired
	LifeSecureLoginService loginService;
	
	Random random=new Random(1000);
	
	@GetMapping("/")
	public String loginPage() {
		
		return "login";
	}
	

	@GetMapping("/verifyUser")
	public String verifyUser(@RequestParam("useremail") String useremail, @RequestParam("password") String password,Model model) {
		System.out.println( useremail + ""+password);
		///
		boolean flag = loginService.verifyUser(useremail, password);
		if(flag) {
			System.out.println("login success");
			
			return "login";
		}

		model.addAttribute("message", "Your user name and password is incorrect please try again::");
		return "login";
	}
	
	@GetMapping("/register")
	public ModelAndView registerPage() {
		System.out.println("registerpage () :::");
		ModelAndView model = null;
	    model =  new ModelAndView("registration", "user", new User());
		return model;
	}
	
	@GetMapping("/forgot")
	public String forgotPassword() {
		return "forgotPassword";
		
	}
	
	@GetMapping("/verifyusername")
	public String verifyusername(@RequestParam("email")String emailId,HttpSession session) {
		System.out.println(emailId);
	//	loginService.getUserByEmail(emailId);
		
		int otp= random.nextInt(999999);
	    System.out.println(otp);
	    session.setAttribute("emailId", emailId);
	    session.setAttribute("oldotp", otp);
	       
	//we can send email to user
	    
		
		String msg="OTP for password reset :"+otp;
		String subject="OTP From secure insurance";
		String form="parthegaurav@gmail.com";
		String to=emailId;
		loginService.sendEmail(msg,subject,form,to);
		
		return "resetpassword";
		}
	
	@GetMapping("/reset")
	public String resetpassword() {
		return "resetpassword";
	}
	
	//we verify the OTP & reset the password
	
	@GetMapping("/savepassword")
	public void verifyOTP(@RequestParam("otp")int otp,@RequestParam("newPassword")String newPassword,HttpServletRequest request) {
		System.out.println(newPassword);
		//get the send Otp from session
			
		HttpSession session = request.getSession(false);
	    int oldotp = (int)session.getAttribute("oldotp");
		String emailId=(String) session.getAttribute("emailId");
		System.out.println("the old otp is session:"+oldotp);
				
		//verify the otp	
		if(otp==oldotp) {
		System.out.println("otp is correct");
		
		loginService.verifyOtp(emailId,newPassword);
	}
		else {
		System.out.println("otp is wrong");
	}
				
		
		
	}
	

}
