package com.orenda.lifesecure.service;

import com.orenda.lifesecure.model.UserDetails;

public interface LifeSecureLoginService {

	boolean getUserByEmail(String emailId);
	
    boolean verifyOtp(String emailId, String newPassword);

	boolean sendEmail(String msg, String subject, String from, String to);

	UserDetails verifyUserCredentilas(String username, String password);

	

}
