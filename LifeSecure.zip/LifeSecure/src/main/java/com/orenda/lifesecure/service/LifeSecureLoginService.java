package com.orenda.lifesecure.service;

public interface LifeSecureLoginService {

	void getUserByEmail(String emailId);
	
    void verifyOtp(String emailId, String newPassword);

	boolean sendEmail(String msg, String subject, String from, String to);

}
