package com.orenda.lifesecure.service;


import java.util.Properties;
import java.util.Random;
import java.util.random.RandomGenerator;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.orenda.lifesecure.dao.LifeSecureLoginDao;
import com.orenda.lifesecure.model.User;

@Service
@SessionAttributes
public class LifeSecureLoginServiceImpl implements LifeSecureLoginService{

	@Autowired
	LifeSecureLoginDao loginDao;
	
	@Override
	public boolean verifyUser(String useremail, String password) {
		// TODO Auto-generated method stub

		User user = loginDao.verifyUser(useremail);
		System.out.println("service");

		if (user != null && user.getPassword().equals(password)) {
			
			return true;
		}

		return false;
	}

	@Override
	public void getUserByEmail(String emailId) {
		
		//loginDao.getUserInDb(emailId);
		
        
       
		
	}
    @Override
	public boolean sendEmail(String msg,String subject,String from,String to) {
		
		Properties properties=System.getProperties();
		
		properties.put("mail.smtp.host", "smtp.gmail.com");
		properties.put("mail.smtp.port", 465);
		properties.put("mail.smtp.ssl.enable", "true");
		properties.put("mail.smtp.auth", "true");
		
		Authenticator auth = new Authenticator() {
            public PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, "gaurav321");
            }
        };
  
        Session session = Session.getInstance(properties, auth);
		try {
		MimeMessage mimemsg=new MimeMessage(session);
		mimemsg.setFrom(from);
		mimemsg.addRecipient(Message.RecipientType.TO,new InternetAddress(to) );
		mimemsg.setText(msg);
		mimemsg.setSubject(subject);
		
		Transport.send(mimemsg);
		System.out.println("sent suceess");
		return true;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return false;
		
		
		
	}

	@Override
	public void verifyOtp(String emailId, String newPassword) {
		
		System.out.println("emailId and new password"+emailId+","+newPassword);


		
	}
	
}
